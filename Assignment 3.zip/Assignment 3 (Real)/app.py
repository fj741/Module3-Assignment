from flask import Flask, render_template, request, redirect, url_for
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, validators
from wtforms.validators import DataRequired, EqualTo, Length, Email, InputRequired
app = Flask(__name__)


class RegisterForm(FlaskForm):
    fname = StringField("First Name", validators=[DataRequired(),InputRequired("Please enter your First Name"),Length(min=2, max=20)])
    lname = StringField("Last Name", validators=[DataRequired(),InputRequired("Please enter your Last Name"),Length(min=2, max=20)])
    email = StringField("Email", validators=[DataRequired(),InputRequired("Please enter a valid Email Address"), Email()])
    password = PasswordField("Password", DataRequired(), InputRequired("Please enter a valid Password"),Length(min=6, max=30))
    confirm_password = PasswordField("Confirm Password", InputRequired("Passwrods do not match"), DataRequired(), EqualTo(password))
    submit = SubmitField("Register")

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/checkout', methods=["POST", "GET"])
def checkout():
    if request.method == "POST":
        return redirect(url_for("home"))
    else:
        return render_template('checkout.html')    
        
@app.route('/register', methods=["POST", "GET"])
def register():     
    form = RegisterForm()   
    return render_template('register.html', form=form)

@app.errorhandler(404)
def page_doesnt_exist(e):
    return render_template('404.html'), 404
    

if __name__ == '__main__':
    app.run(debug = True)