let circle = document.querySelectorAll('.circle');
let closeButton = document.getElementById('closeButton')
let openButton = document.getElementById('openButton')
let navigation = document.getElementById('navigation')



closeButton.addEventListener("click",() =>{
    navigation.style.right = "-200px";
    navigation.style.transition = "0.3s ease-in-out";
})
openButton.addEventListener("click",() =>{
    navigation.style.right = "0px";
    navigation.style.transition = "0.3s ease-in-out";
})

circle.forEach(btn =>{
    btn.addEventListener("click", () =>{
        document.querySelector('.buttons .active').classList.remove('active');
        btn.classList.add('active');
        let src = btn.getAttribute('data-src');
        document.querySelector('#first_image').src = src;
    })
})

